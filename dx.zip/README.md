# M.M

M.M DX library for mta sa game hope u enjoy with it 

-----

# Functions

  	dxCreateWindow
  	(x,y,width,height,text,backcolor,titlecolor,barcolor,bordercolor,sizeoftext)
  
	dxCreateButton(x,y,width,height,text,baba,backcolor,backcolor2,textcolor,textcolor2,bordercolor,bordercolor2,textsize)
	 
	dxCreateTabPanel
	
	dxCreateTab
	
	dxCreateCheckBox
	
	dxCreateMemo
	
	dxCreateLabel
	
	dxCreateGridList
	
	dxCreateEdit
	
	dxCreateProgressBar
	
	dxCreateRadioButton
	
	dxCreateScrollBar
	
	dxCreateImage
	
	dxSetVisible
	
	dxGetVisible
	
	dxGetText
	
	dxSetText
	
	dxSetPosition
	
	dxGetPosition
	
	dxSetSize
	
	dxGetSize
	
	dxLabelGetColor
	
	dxLabelSetHorizontalAlign
	
	dxLabelSetVerticalAlign
	
	dxProgressBarSetProgress
	
	dxProgressBarGetProgress
	
	dxProgressBarSetText
	
	dxRadioButtonGetSelected
	
	dxRadioButtonSetSelected
	
	dxGidListAddColumn
	
	dxGridListAddRow
	
	dxGridListGetColumnWidth
	
	dxGridListSetItemText
	
	dxCheckBoxGetSelected
	
	dxCheckBoxSetSelected
	
	dxWindowSetMovable

	dxWindowIsMovable
	
	
