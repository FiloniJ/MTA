Elements={}
createdElements={}
oldrow=0
resElements={}
bannedelements={
['dxGridListRow']=true,
['dxGridListColumn']=true,


}
 bannedchars={
 ['f1']=true,
 ['f2']=true,
 ['f3']=true,
 ['f4']=true,
 ['f5']=true,
 ['f6']=true,
 ['f7']=true,
 ['f8']=true,
 ['f9']=true,
 ['f10']=true,
 ['f11']=true,
 ['f12']=true,
 ['delete']=true,
 ['home']=true,
 ['end']=true,
 ['pageup']=true,
 ['pagedown']=true,
 ['arrow_l']=true,
 ['arrow_r']=true,
 ['lctrl']=true,
 ['rctrl']=true,
 ['lalt']=true,
 ['ralt']=true,
 ['rshift']=true,
 ['lshift']=true,
 ['capslock']=true,
 ['tab']=true,
 ['escape']=true,
 ['`']=true,
 }
 
  alltypes={'dxGidList','dxWindow','dxButton','dxCheckBox','dxLabel','dxRadioButton','dxEdit','dxScrollBar','dxProgressBar','dxMemo','dxImage'}
 
